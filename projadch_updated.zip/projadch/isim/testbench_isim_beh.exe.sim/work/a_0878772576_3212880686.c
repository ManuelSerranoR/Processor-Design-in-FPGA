/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Anirudh Dinesh/Downloads/projadch2/projadch/PCBlock.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
char *ieee_p_3620187407_sub_674691591_3965413181(char *, char *, char *, char *, unsigned char );
char *ieee_p_3620187407_sub_767668596_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_0878772576_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 568U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 2800);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(53, ng0);
    t3 = (t0 + 684U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 1328U);
    t3 = *((char **)t1);
    t1 = (t0 + 2868);
    t4 = (t1 + 32U);
    t7 = *((char **)t4);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 32U);
    xsi_driver_first_trans_fast(t1);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(54, ng0);
    t3 = (t0 + 5299);
    t8 = (t0 + 2868);
    t9 = (t8 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast(t8);
    goto LAB6;

}

static void work_a_0878772576_3212880686_p_1(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(62, ng0);

LAB3:    t2 = (t0 + 1420U);
    t3 = *((char **)t2);
    t2 = (t0 + 5116U);
    t4 = ieee_p_3620187407_sub_674691591_3965413181(IEEE_P_3620187407, t1, t3, t2, (unsigned char)3);
    t5 = (t1 + 12U);
    t6 = *((unsigned int *)t5);
    t7 = (1U * t6);
    t8 = (32U != t7);
    if (t8 == 1)
        goto LAB5;

LAB6:    t9 = (t0 + 2904);
    t10 = (t9 + 32U);
    t11 = *((char **)t10);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 32U);
    xsi_driver_first_trans_fast(t9);

LAB2:    t14 = (t0 + 2808);
    *((int *)t14) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(32U, t7, 0);
    goto LAB6;

}

static void work_a_0878772576_3212880686_p_2(char *t0)
{
    char t21[16];
    char t22[16];
    char t27[16];
    char t29[16];
    unsigned char t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    char *t28;
    char *t30;
    char *t31;
    int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;

LAB0:    xsi_set_current_line(67, ng0);
    t3 = (t0 + 960U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)2);
    if (t6 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:    t3 = (t0 + 960U);
    t4 = *((char **)t3);
    t1 = *((unsigned char *)t4);
    t2 = (t1 == (unsigned char)3);
    if (t2 != 0)
        goto LAB11;

LAB12:    t3 = (t0 + 1052U);
    t4 = *((char **)t3);
    t1 = *((unsigned char *)t4);
    t2 = (t1 == (unsigned char)3);
    if (t2 != 0)
        goto LAB15;

LAB16:    t3 = (t0 + 1144U);
    t4 = *((char **)t3);
    t1 = *((unsigned char *)t4);
    t2 = (t1 == (unsigned char)3);
    if (t2 != 0)
        goto LAB19;

LAB20:
LAB3:    t3 = (t0 + 2816);
    *((int *)t3) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(67, ng0);
    t3 = (t0 + 1512U);
    t13 = *((char **)t3);
    t3 = (t0 + 2940);
    t14 = (t3 + 32U);
    t15 = *((char **)t14);
    t16 = (t15 + 40U);
    t17 = *((char **)t16);
    memcpy(t17, t13, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB3;

LAB5:    t3 = (t0 + 1144U);
    t10 = *((char **)t3);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)2);
    t1 = t12;
    goto LAB7;

LAB8:    t3 = (t0 + 1052U);
    t7 = *((char **)t3);
    t8 = *((unsigned char *)t7);
    t9 = (t8 == (unsigned char)2);
    t2 = t9;
    goto LAB10;

LAB11:    xsi_set_current_line(68, ng0);
    t3 = (t0 + 1512U);
    t7 = *((char **)t3);
    t18 = (31 - 31);
    t19 = (t18 * 1U);
    t20 = (0 + t19);
    t3 = (t7 + t20);
    t10 = (t0 + 776U);
    t13 = *((char **)t10);
    t14 = ((IEEE_P_2592010699) + 2332);
    t15 = (t22 + 0U);
    t16 = (t15 + 0U);
    *((int *)t16) = 31;
    t16 = (t15 + 4U);
    *((int *)t16) = 28;
    t16 = (t15 + 8U);
    *((int *)t16) = -1;
    t23 = (28 - 31);
    t24 = (t23 * -1);
    t24 = (t24 + 1);
    t16 = (t15 + 12U);
    *((unsigned int *)t16) = t24;
    t16 = (t0 + 5068U);
    t10 = xsi_base_array_concat(t10, t21, t14, (char)97, t3, t22, (char)97, t13, t16, (char)101);
    t17 = (t0 + 5331);
    t28 = ((IEEE_P_2592010699) + 2332);
    t30 = (t29 + 0U);
    t31 = (t30 + 0U);
    *((int *)t31) = 0;
    t31 = (t30 + 4U);
    *((int *)t31) = 1;
    t31 = (t30 + 8U);
    *((int *)t31) = 1;
    t32 = (1 - 0);
    t24 = (t32 * 1);
    t24 = (t24 + 1);
    t31 = (t30 + 12U);
    *((unsigned int *)t31) = t24;
    t26 = xsi_base_array_concat(t26, t27, t28, (char)97, t10, t21, (char)97, t17, t29, (char)101);
    t24 = (4U + 26U);
    t33 = (t24 + 2U);
    t5 = (32U != t33);
    if (t5 == 1)
        goto LAB13;

LAB14:    t31 = (t0 + 2940);
    t34 = (t31 + 32U);
    t35 = *((char **)t34);
    t36 = (t35 + 40U);
    t37 = *((char **)t36);
    memcpy(t37, t26, 32U);
    xsi_driver_first_trans_fast(t31);
    goto LAB3;

LAB13:    xsi_size_not_matching(32U, t33, 0);
    goto LAB14;

LAB15:    xsi_set_current_line(69, ng0);
    t3 = (t0 + 1512U);
    t7 = *((char **)t3);
    t3 = (t0 + 5116U);
    t10 = (t0 + 868U);
    t13 = *((char **)t10);
    t10 = (t0 + 5084U);
    t14 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t21, t7, t3, t13, t10);
    t15 = (t21 + 12U);
    t18 = *((unsigned int *)t15);
    t19 = (1U * t18);
    t5 = (32U != t19);
    if (t5 == 1)
        goto LAB17;

LAB18:    t16 = (t0 + 2940);
    t17 = (t16 + 32U);
    t25 = *((char **)t17);
    t26 = (t25 + 40U);
    t28 = *((char **)t26);
    memcpy(t28, t14, 32U);
    xsi_driver_first_trans_fast(t16);
    goto LAB3;

LAB17:    xsi_size_not_matching(32U, t19, 0);
    goto LAB18;

LAB19:    xsi_set_current_line(70, ng0);
    t3 = (t0 + 1420U);
    t7 = *((char **)t3);
    t3 = (t0 + 2940);
    t10 = (t3 + 32U);
    t13 = *((char **)t10);
    t14 = (t13 + 40U);
    t15 = *((char **)t14);
    memcpy(t15, t7, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB3;

}

static void work_a_0878772576_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(77, ng0);

LAB3:    t1 = (t0 + 1420U);
    t2 = *((char **)t1);
    t1 = (t0 + 2976);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 2824);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0878772576_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0878772576_3212880686_p_0,(void *)work_a_0878772576_3212880686_p_1,(void *)work_a_0878772576_3212880686_p_2,(void *)work_a_0878772576_3212880686_p_3};
	xsi_register_didat("work_a_0878772576_3212880686", "isim/testbench_isim_beh.exe.sim/work/a_0878772576_3212880686.didat");
	xsi_register_executes(pe);
}
