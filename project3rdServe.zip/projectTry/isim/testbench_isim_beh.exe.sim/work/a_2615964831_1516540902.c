/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/mos28/Documents/xilinx proj/projectTry/register-file.vhd";
extern char *IEEE_P_3620187407;

int ieee_p_3620187407_sub_514432868_3965413181(char *, char *, char *);


static void work_a_2615964831_1516540902_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int t7;
    int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    unsigned char t20;
    char *t21;
    char *t23;
    char *t25;
    char *t27;
    char *t29;
    char *t31;
    char *t33;
    char *t35;
    char *t37;
    char *t39;
    char *t41;
    char *t43;
    char *t45;
    char *t47;
    char *t49;
    char *t51;
    char *t53;
    char *t55;
    char *t57;
    char *t59;
    char *t61;
    char *t63;
    char *t65;
    char *t67;
    char *t69;
    char *t71;
    char *t73;
    char *t75;
    char *t77;
    char *t79;
    char *t81;
    char *t82;
    char *t83;
    char *t84;
    char *t85;

LAB0:    xsi_set_current_line(50, ng0);
    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t1 = (t0 + 4192);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 1024U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(51, ng0);
    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t1 = (t0 + 1032U);
    t3 = *((char **)t1);
    t1 = (t0 + 6720U);
    t7 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t3, t1);
    t8 = (t7 - 31);
    t9 = (t8 * -1);
    xsi_vhdl_check_range_of_index(31, 0, -1, t7);
    t10 = (32U * t9);
    t11 = (0 + t10);
    t4 = (t2 + t11);
    t5 = (t0 + 4256);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t4, 32U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 6736U);
    t7 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t3, t1);
    t8 = (t7 - 31);
    t9 = (t8 * -1);
    xsi_vhdl_check_range_of_index(31, 0, -1, t7);
    t10 = (32U * t9);
    t11 = (0 + t10);
    t4 = (t2 + t11);
    t5 = (t0 + 4320);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t4, 32U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1632U);
    t16 = xsi_signal_has_event(t1);
    if (t16 == 1)
        goto LAB5;

LAB6:    t15 = (unsigned char)0;

LAB7:    if (t15 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4112);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(55, ng0);
    t2 = (t0 + 1832U);
    t4 = *((char **)t2);
    t19 = *((unsigned char *)t4);
    t20 = (t19 == (unsigned char)3);
    if (t20 != 0)
        goto LAB8;

LAB10:    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t15 = *((unsigned char *)t2);
    t16 = (t15 == (unsigned char)2);
    if (t16 != 0)
        goto LAB11;

LAB12:
LAB9:    goto LAB3;

LAB5:    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t17 = *((unsigned char *)t3);
    t18 = (t17 == (unsigned char)3);
    t15 = t18;
    goto LAB7;

LAB8:    xsi_set_current_line(56, ng0);
    t2 = xsi_get_transient_memory(1024U);
    memset(t2, 0, 1024U);
    t5 = t2;
    t6 = (t0 + 7898);
    memcpy(t5, t6, 32U);
    t5 = (t5 + 32U);
    t13 = (t0 + 7930);
    memcpy(t5, t13, 32U);
    t5 = (t5 + 32U);
    t21 = (t0 + 7962);
    memcpy(t5, t21, 32U);
    t5 = (t5 + 32U);
    t23 = (t0 + 7994);
    memcpy(t5, t23, 32U);
    t5 = (t5 + 32U);
    t25 = (t0 + 8026);
    memcpy(t5, t25, 32U);
    t5 = (t5 + 32U);
    t27 = (t0 + 8058);
    memcpy(t5, t27, 32U);
    t5 = (t5 + 32U);
    t29 = (t0 + 8090);
    memcpy(t5, t29, 32U);
    t5 = (t5 + 32U);
    t31 = (t0 + 8122);
    memcpy(t5, t31, 32U);
    t5 = (t5 + 32U);
    t33 = (t0 + 8154);
    memcpy(t5, t33, 32U);
    t5 = (t5 + 32U);
    t35 = (t0 + 8186);
    memcpy(t5, t35, 32U);
    t5 = (t5 + 32U);
    t37 = (t0 + 8218);
    memcpy(t5, t37, 32U);
    t5 = (t5 + 32U);
    t39 = (t0 + 8250);
    memcpy(t5, t39, 32U);
    t5 = (t5 + 32U);
    t41 = (t0 + 8282);
    memcpy(t5, t41, 32U);
    t5 = (t5 + 32U);
    t43 = (t0 + 8314);
    memcpy(t5, t43, 32U);
    t5 = (t5 + 32U);
    t45 = (t0 + 8346);
    memcpy(t5, t45, 32U);
    t5 = (t5 + 32U);
    t47 = (t0 + 8378);
    memcpy(t5, t47, 32U);
    t5 = (t5 + 32U);
    t49 = (t0 + 8410);
    memcpy(t5, t49, 32U);
    t5 = (t5 + 32U);
    t51 = (t0 + 8442);
    memcpy(t5, t51, 32U);
    t5 = (t5 + 32U);
    t53 = (t0 + 8474);
    memcpy(t5, t53, 32U);
    t5 = (t5 + 32U);
    t55 = (t0 + 8506);
    memcpy(t5, t55, 32U);
    t5 = (t5 + 32U);
    t57 = (t0 + 8538);
    memcpy(t5, t57, 32U);
    t5 = (t5 + 32U);
    t59 = (t0 + 8570);
    memcpy(t5, t59, 32U);
    t5 = (t5 + 32U);
    t61 = (t0 + 8602);
    memcpy(t5, t61, 32U);
    t5 = (t5 + 32U);
    t63 = (t0 + 8634);
    memcpy(t5, t63, 32U);
    t5 = (t5 + 32U);
    t65 = (t0 + 8666);
    memcpy(t5, t65, 32U);
    t5 = (t5 + 32U);
    t67 = (t0 + 8698);
    memcpy(t5, t67, 32U);
    t5 = (t5 + 32U);
    t69 = (t0 + 8730);
    memcpy(t5, t69, 32U);
    t5 = (t5 + 32U);
    t71 = (t0 + 8762);
    memcpy(t5, t71, 32U);
    t5 = (t5 + 32U);
    t73 = (t0 + 8794);
    memcpy(t5, t73, 32U);
    t5 = (t5 + 32U);
    t75 = (t0 + 8826);
    memcpy(t5, t75, 32U);
    t5 = (t5 + 32U);
    t77 = (t0 + 8858);
    memcpy(t5, t77, 32U);
    t5 = (t5 + 32U);
    t79 = (t0 + 8890);
    memcpy(t5, t79, 32U);
    t81 = (t0 + 4384);
    t82 = (t81 + 56U);
    t83 = *((char **)t82);
    t84 = (t83 + 56U);
    t85 = *((char **)t84);
    memcpy(t85, t2, 1024U);
    xsi_driver_first_trans_delta(t81, 0U, 1024U, 0LL);
    xsi_set_current_line(65, ng0);
    t1 = xsi_get_transient_memory(32U);
    memset(t1, 0, 32U);
    t2 = t1;
    memset(t2, (unsigned char)2, 32U);
    t3 = (t0 + 4256);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    memcpy(t12, t1, 32U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(66, ng0);
    t1 = xsi_get_transient_memory(32U);
    memset(t1, 0, 32U);
    t2 = t1;
    memset(t2, (unsigned char)2, 32U);
    t3 = (t0 + 4320);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t12 = *((char **)t6);
    memcpy(t12, t1, 32U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB9;

LAB11:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t17 = *((unsigned char *)t3);
    t18 = (t17 == (unsigned char)3);
    if (t18 != 0)
        goto LAB13;

LAB15:
LAB14:    goto LAB9;

LAB13:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 1992U);
    t4 = *((char **)t1);
    t1 = (t0 + 1352U);
    t5 = *((char **)t1);
    t1 = (t0 + 6752U);
    t7 = ieee_p_3620187407_sub_514432868_3965413181(IEEE_P_3620187407, t5, t1);
    t8 = (t7 - 31);
    t9 = (t8 * -1);
    t10 = (32U * t9);
    t11 = (0U + t10);
    t6 = (t0 + 4384);
    t12 = (t6 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t21 = *((char **)t14);
    memcpy(t21, t4, 32U);
    xsi_driver_first_trans_delta(t6, t11, 32U, 0LL);
    goto LAB14;

}


extern void work_a_2615964831_1516540902_init()
{
	static char *pe[] = {(void *)work_a_2615964831_1516540902_p_0};
	xsi_register_didat("work_a_2615964831_1516540902", "isim/testbench_isim_beh.exe.sim/work/a_2615964831_1516540902.didat");
	xsi_register_executes(pe);
}
