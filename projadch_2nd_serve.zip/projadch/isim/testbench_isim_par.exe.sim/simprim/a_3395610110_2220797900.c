/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif



static void simprim_a_3395610110_2220797900_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:
LAB3:    t1 = (t0 + 2720);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}


extern void simprim_a_3395610110_2220797900_1026574172_init()
{
	static char *pe[] = {(void *)simprim_a_3395610110_2220797900_p_0};
	xsi_register_didat("simprim_a_3395610110_2220797900_1026574172", "isim/testbench_isim_par.exe.sim/simprim/a_3395610110_2220797900_1026574172.didat");
	xsi_register_executes(pe);
}

extern void simprim_a_3395610110_2220797900_3094435178_init()
{
	static char *pe[] = {(void *)simprim_a_3395610110_2220797900_p_0};
	xsi_register_didat("simprim_a_3395610110_2220797900_3094435178", "isim/testbench_isim_par.exe.sim/simprim/a_3395610110_2220797900_3094435178.didat");
	xsi_register_executes(pe);
}

extern void simprim_a_3395610110_2220797900_1439739167_init()
{
	static char *pe[] = {(void *)simprim_a_3395610110_2220797900_p_0};
	xsi_register_didat("simprim_a_3395610110_2220797900_1439739167", "isim/testbench_isim_par.exe.sim/simprim/a_3395610110_2220797900_1439739167.didat");
	xsi_register_executes(pe);
}

extern void simprim_a_3395610110_2220797900_0859907718_init()
{
	static char *pe[] = {(void *)simprim_a_3395610110_2220797900_p_0};
	xsi_register_didat("simprim_a_3395610110_2220797900_0859907718", "isim/testbench_isim_par.exe.sim/simprim/a_3395610110_2220797900_0859907718.didat");
	xsi_register_executes(pe);
}

extern void simprim_a_3395610110_2220797900_1902852246_init()
{
	static char *pe[] = {(void *)simprim_a_3395610110_2220797900_p_0};
	xsi_register_didat("simprim_a_3395610110_2220797900_1902852246", "isim/testbench_isim_par.exe.sim/simprim/a_3395610110_2220797900_1902852246.didat");
	xsi_register_executes(pe);
}

extern void simprim_a_3395610110_2220797900_1839319118_init()
{
	static char *pe[] = {(void *)simprim_a_3395610110_2220797900_p_0};
	xsi_register_didat("simprim_a_3395610110_2220797900_1839319118", "isim/testbench_isim_par.exe.sim/simprim/a_3395610110_2220797900_1839319118.didat");
	xsi_register_executes(pe);
}

extern void simprim_a_3395610110_2220797900_1818468985_init()
{
	static char *pe[] = {(void *)simprim_a_3395610110_2220797900_p_0};
	xsi_register_didat("simprim_a_3395610110_2220797900_1818468985", "isim/testbench_isim_par.exe.sim/simprim/a_3395610110_2220797900_1818468985.didat");
	xsi_register_executes(pe);
}

extern void simprim_a_3395610110_2220797900_0433961640_init()
{
	static char *pe[] = {(void *)simprim_a_3395610110_2220797900_p_0};
	xsi_register_didat("simprim_a_3395610110_2220797900_0433961640", "isim/testbench_isim_par.exe.sim/simprim/a_3395610110_2220797900_0433961640.didat");
	xsi_register_executes(pe);
}
